# JyotiTiwari

Steps to be followed
1. Open folder.
2. Install npm using "npm install"
5. Run your project using "ng serve" or "npm start".